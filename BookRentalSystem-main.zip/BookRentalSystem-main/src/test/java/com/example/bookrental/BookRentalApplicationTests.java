package com.example.bookrental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookRentalApplicationTests {

    @Test
    void contextLoads() {
    }

}
