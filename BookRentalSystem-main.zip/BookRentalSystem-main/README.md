A book rental service implemented using spring boot and MVC architecture which uses spring security for basic authentication.
